# Research Sources

Research performed August 7, 2026.

## Claude Code / skill design
- https://claude.com/blog/lessons-from-building-claude-code-how-we-use-skills
- https://support.claude.com/en/articles/14554000-claude-code-power-user-tips
- https://support.claude.com/en/articles/12512176-what-are-skills

## Security
- https://owasp.org/Top10/
- https://owasp.org/Top10/2025/A03_2025-Software_Supply_Chain_Failures/
- https://owasp.org/API-Security/editions/2023/en/0x11-t10/
- https://cornucopia.owasp.org/taxonomy/asvs-5.0
- https://csrc.nist.gov/pubs/sp/800/218/final
- https://csrc.nist.gov/projects/ssdf

## Backend / data
- https://www.postgresql.org/docs/current/
- https://www.postgresql.org/docs/current/ddl-rowsecurity.html
- https://www.postgresql.org/docs/current/indexes.html
- https://www.12factor.net/

## AI systems
- https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
- https://www.anthropic.com/engineering/writing-tools-for-agents
- https://openai.com/business/guides-and-resources/a-practical-guide-to-building-ai-agents/
- https://openai.com/index/new-tools-for-building-agents/
- https://openai.com/index/introducing-structured-outputs-in-the-api/

## Reliability / observability
- https://sre.google/workbook/table-of-contents/
- https://sre.google/sre-book/service-best-practices/
- https://sre.google/workbook/error-budget-policy/
- https://sre.google/resources/practices-and-processes/incident-management-guide/
- https://sre.google/workbook/eliminating-toil/
- https://opentelemetry.io/docs/

## NEXUS GODMODE MASTER additions
Research checked August 7, 2026.

## Claude Skills / Context Engineering

Anthropic reports that the strongest skills are narrowly useful, focus on non-obvious knowledge and gotchas,
and use the file system for progressive disclosure instead of stuffing everything into `SKILL.md`.

- https://claude.com/blog/lessons-from-building-claude-code-how-we-use-skills
- https://claude.com/blog/skills-explained
- https://claude.com/blog/steering-claude-code-skills-hooks-rules-subagents-and-more

## Subagents / Fresh Context

Anthropic recommends subagents for research-heavy side tasks, independent work, and fresh-perspective
verification because their intermediate context does not pollute the parent session.

- https://claude.com/blog/subagents-in-claude-code
- https://claude.com/blog/using-claude-code-session-management-and-1m-context

## Verification / Evals

Anthropic recommends eval-driven development for agent systems and combining code-based, model-based,
and human graders according to the property being measured.

- https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents

## Evaluator–Optimizer

Anthropic's agent guidance documents evaluator–optimizer as a useful workflow when criteria are clear and
iteration produces measurable gains.

- https://www.anthropic.com/engineering/building-effective-agents

## Tool Design

Agent tools should have clear scope, meaningful context, and token-efficient responses.

- https://www.anthropic.com/engineering/writing-tools-for-agents

## Innovation / Divergent-Convergent Thinking

The Design Council Double Diamond distinguishes exploration/divergence from definition/convergence,
then repeats that pattern for solution development and delivery/testing.

- https://www.designcouncil.org.uk/resources/the-double-diamond/
- https://www.designcouncil.org.uk/resources/framework-for-innovation/

## Prompt Caching / Efficiency

Claude Code's harness is designed around prompt caching and advises stable prefixes and deferred tool/context
loading rather than constantly mutating always-loaded instructions.

- https://claude.com/blog/lessons-from-building-claude-code-prompt-caching-is-everything
