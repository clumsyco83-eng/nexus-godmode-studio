# NEXUS GODMODE MASTER SUITE

This package contains the **11 NEXUS core/foundation skills built in this conversation**.

The new top-level `nexus-godmode-master` skill orchestrates the existing ten rather than replacing them.

## Master layer

1. `nexus-godmode-master` — 🧠 Supermind reasoning → 🧙 High Wizard invention → ⚡ Godmode execution → 🛡 Verification → 🔁 Recursive improvement.

## Existing core team

2. `godmode-v2` — mission execution and delivery orchestration.
3. `principal-architecture` — long-term architecture and system evolution.
4. `token-optimizer-v2` — context/token/tool efficiency.
5. `project-memory-continuity` — durable project memory and handoffs.
6. `engineering-intelligence` — repository understanding, root-cause debugging, Git intelligence.
7. `security-guardian` — security review and defensive hardening.
8. `backend-data-engineer` — APIs, data, migrations, queues, storage, backend correctness.
9. `ai-systems-engineer` — production AI/agents, RAG, tools, evals, guardrails.
10. `technology-research-scout` — current evidence for technology decisions.
11. `platform-sre-engineer` — CI/CD, observability, SLOs, incidents, production reliability.

## Important architecture

Do **not** load all 11 skills for every task.

`nexus-godmode-master` is a router and meta-orchestrator. It activates only the specialist needed for the
current phase and works with Token Optimizer to protect the context window.

The older nine NEXUS Studio creative/product specialist skills are intentionally not included in this ZIP.


---

# NEXUS CORE SKILLS — Foundation + Missing Specialists

This package contains the **10 skills built in this conversation**.

It intentionally does **not** include the older nine NEXUS Studio specialist skills
(Game Studio, Mobile App Studio, Figma, Higgsfield, Animation/VFX, QA, Store Release,
ASO/Growth, AI Product Strategy), because those already exist separately.

## Included skills

### Foundation
1. `godmode-v2` — mission orchestration, task graphs, risk, delegation, verification, completion.
2. `principal-architecture` — long-term system architecture, evolution, governance, resilience.
3. `token-optimizer-v2` — context, token, tool, model, session, and subagent efficiency.

### New missing skills
4. `project-memory-continuity` — durable project memory, checkpoints, decisions, stale-memory control.
5. `engineering-intelligence` — repository onboarding, code archaeology, root-cause debugging, Git intelligence.
6. `security-guardian` — defensive threat modeling, secure design/review, auth/API/supply-chain security.
7. `backend-data-engineer` — APIs, databases, migrations, queues, caching, realtime, data integrity.
8. `ai-systems-engineer` — production AI/agents, RAG, tools, memory, evals, guardrails, cost/reliability.
9. `technology-research-scout` — current technology research, evidence matrices, compatibility, TCO, PoCs.
10. `platform-sre-engineer` — cloud/platform, CI/CD, SLOs, observability, incidents, recovery, production reliability.

## Design philosophy

- Skills are narrowly scoped enough to avoid confusing overlap.
- Main `SKILL.md` files contain operating rules.
- Detailed material lives in `references/REFERENCE.md` for progressive disclosure.
- Godmode coordinates; specialist skills own domain decisions.
- Principal Architecture handles structural/one-way-door decisions.
- Token Optimizer prevents unnecessary skill/context/tool expansion.
- Project Memory preserves only durable high-signal state.
- Evidence and verification outrank confident prose.

## Suggested operating stack

For a substantial project, do **not** invoke all skills at once.

Typical:
- Godmode v2
- Token Optimizer v2
- one active specialist

Add:
- Principal Architecture for structural choices
- Security Guardian for sensitive/high-risk work
- Project Memory at checkpoints/handoffs
- QA from the separate older NEXUS Studio pack for release validation

This keeps context efficient.

## Research foundation

The new skills were informed by current primary guidance from Anthropic/Claude,
OWASP, NIST, PostgreSQL, Google SRE, OpenTelemetry, OpenAI, and Twelve-Factor App.
See `RESEARCH_SOURCES.md`.
